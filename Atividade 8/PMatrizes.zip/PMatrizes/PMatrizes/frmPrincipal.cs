﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Deployment.Internal;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                Application.OpenForms["frmExercicio5"].BringToFront();
            }
            else
            {
                frmExercicio5 frm5 = new frmExercicio5();
                frm5.Show();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (int i = 0; i<20; i++)
            {
                auxiliar = Interaction.InputBox ($"Digite o {i + 1} número", "Entrada de Dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Valor Inválido!");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";
            auxiliar = string.Join("\n", vetor);
            MessageBox.Show(auxiliar);  
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new

            ArrayList() { "Ana", "André", "Beatriz", "Camila", "João", "Joana", "Otávio", "Marcelo", "Pedro", "Thaís" };

            lista.Remove("Otávio");
            string auxiliar = "";

            foreach (string nome in lista)
            {
                auxiliar += nome + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Double[,] Notas = new double[20, 3];
            string auxiliar = "";
            Double media = 0;
            string saida = "";

            for (int i = 0; i<20; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {j + 1} do eixo {i + 1}", "Entrada de Dados");

                    if (!(Double.TryParse(auxiliar, out Notas[i,j]) || Notas[i,j]<0 || Notas[i,j]>10))
                    {
                        MessageBox.Show("Dados Inválidos!");
                    }
                    else
                    {
                        media += Notas[i, j];
                    }
                }
            saida += $"\nAluno {i + 1}: Média = {media / 3}";
            media = 0;
            }
            MessageBox.Show(saida);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                Application.OpenForms["frmExercicio4"].BringToFront();
            }
            else
            {
                frmExercicio4 frm4 = new frmExercicio4();
                frm4.Show();
            }
        }
    }
}
