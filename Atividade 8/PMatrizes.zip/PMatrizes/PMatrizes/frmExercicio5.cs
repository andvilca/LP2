﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string[] gabarito { "A", "B", "C", "D", "E", "A", "B", "C", "D", "E"};

            string[,] respostas = new string[3, 10];
            string auxiliar;

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    auxiliar = Interaction.InputBox($"Aluno {j + 1} digite a resposta {i + 1}", "Entrada de Dados");

                    if (string.IsNullOrEmpty(auxiliar) || !"ABCDE".Contains(auxiliar))
                    {
                        MessageBox.Show("Dados Inválidos!");
                    }
                    else
                    {
                        respostas[i,j] = auxiliar;
                    }
                    if (auxiliar == gabarito[j])
                    {
                        listBox1.Items.Add($"O aluno {respostas[i]} acertou a questão {tamanho[i]} caracteres.");
                    }
                }
            }
        }
    }
}
