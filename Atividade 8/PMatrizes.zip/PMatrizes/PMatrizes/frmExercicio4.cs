﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            int[] tamanho = new int[10];
            string auxiliar = "";

            for (int i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1} nome: ", "Entrada de Dados");
                
                if (auxiliar == "")
                {
                    MessageBox.Show("Valor Inválido!");
                    i--;
                }
                else
                {
                    nomes[i] = auxiliar;
                    tamanho[i] = nomes[i].Replace(" ", "").Length;
                }
            }
            for (int i = 0; i < 10; i++)
            {
                listBox1.Items.Add($"O nome {nomes[i]} tem {tamanho[i]} caracteres.");
            }
        }
    }
}
