﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double A, B, C;

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider1.SetError(textBox1, "");
                A = Convert.ToDouble(textBox1.Text);
                if (A <= 0)
                {
                    errorProvider1.SetError(textBox1, "Valor não pode ser menor ou igual a 0!");
                    textBox1.Focus();
                }
            }
            catch
            {
                errorProvider1.SetError(textBox1, "Valor inválido!");
                textBox1.Focus();
            }
            
        }

        private void textBox2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(textBox2, "");
                B = Convert.ToDouble(textBox2.Text);
                if (B <= 0)
                {
                    errorProvider2.SetError(textBox2, "Valor não pode ser menor ou igual a 0!");
                    textBox2.Focus();
                }
            }
            catch
            {
                errorProvider2.SetError(textBox2, "Valor inválido!");
                textBox2.Focus();
            }
            
        }

        private void textBox3_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider3.SetError(textBox3, "");
                C = Convert.ToDouble(textBox3.Text);
                if (C <= 0)
                {
                    errorProvider3.SetError(textBox3, "Valor não pode ser menor ou igual a 0!");
                    textBox3.Focus();
                }
            }
            catch
            {
                errorProvider3.SetError(textBox3, "Valor inválido!");
                textBox3.Focus();
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((A < B + C && A > Math.Abs(B - C)) && (B < A + C && B > Math.Abs(A - C)) && (C < A + B && C > Math.Abs(B - C)))
            {
                if (A == B && B == C)
                {
                    MessageBox.Show("Esse é um triângulo EQUILÁTERO!");
                }
                else
                {
                    if ((A == B && B != C) || (A == C && B != A))
                    {
                        MessageBox.Show("Esse é um triângulo ISÒSCELES!");
                    }
                    else
                    {
                        MessageBox.Show("Esse é um triângulo ESCALENO!");
                    }
                }
            }
            else
            {
                errorProvider1.SetError(textBox1, "Valor do lado A é inválido!");
                errorProvider2.SetError(textBox2, "Valor do lado B é inválido!");
                errorProvider3.SetError(textBox3, "Valor do lado C é inválido!");
            }

        }

        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }
    }
}
