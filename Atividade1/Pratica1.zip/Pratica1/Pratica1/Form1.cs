﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pratica1
{
    public partial class Form1 : Form
    {
        Double raio, altura, volume;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = String.Empty;
            textBox3.Clear();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(textBox2.Text, out altura)
               || (altura <= 0))
            {
                MessageBox.Show("Altura Inválida!");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(textBox1.Text, out raio)
                || (raio <= 0))
            {
                MessageBox.Show("Raio Inválido!");
                textBox1.Focus();
            }
            else
                if (!Double.TryParse(textBox2.Text, out altura)
               || (altura <= 0))
            {
                MessageBox.Show("Altura Inválida!");
                textBox2.Focus();
            }
            else 
            {
                volume = Math.PI * Math.Pow(raio, 2) * altura;
                textBox3.Text = volume.ToString("N2");
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(textBox1.Text, out raio)
                || (raio <= 0))
            {
                MessageBox.Show("Raio Inválido!");
            }
            //else
            //    if (raio <= 0)
            //{
            //    MessageBox.Show("Raio deve ser maior que zero!");
            //}
        }
    }
}
