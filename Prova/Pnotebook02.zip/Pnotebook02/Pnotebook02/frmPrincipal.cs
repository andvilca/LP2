﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Pnotebook02
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void botaoLimpar_Click(object sender, EventArgs e)
        {
            listBox.Items.Clear();
        }

        private void botaoExecutar_Click(object sender, EventArgs e)
        {
            double[,] notebooks = new double[2, 3];
            string auxiliar = "";
            double media = 0;
            double mediaGeral = 0;

            for (int i = 0; i < 2; i++)
            {
                listBox.Items.Add($"Notebook {i + 1}");

                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite o valor do notebook {i + 1} na loja {j + 1}", "Entrada de Dados");

                    if (!(Double.TryParse(auxiliar, out notebooks[i, j]) || notebooks[i, j] < 0))
                    {
                        MessageBox.Show("Dados Inválidos!");
                    }
                    else
                    {
                        media += notebooks[i, j];
                    }
                    listBox.Items.Add($"Loja {j + 1}: R$ {notebooks[i, j]}");
                }

                listBox.Items.Add($"Média: R$ {media / 3}");
                mediaGeral += media / 3;
                media = 0;

            }
            listBox.Items.Add($"Média geral dos notebooks = R$ {mediaGeral / 2}");


        }
    }
}
