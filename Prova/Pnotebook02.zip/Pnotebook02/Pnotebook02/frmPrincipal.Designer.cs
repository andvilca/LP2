﻿namespace Pnotebook02
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox = new System.Windows.Forms.ListBox();
            this.botaoExecutar = new System.Windows.Forms.Button();
            this.botaoLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listBox
            // 
            this.listBox.FormattingEnabled = true;
            this.listBox.ItemHeight = 20;
            this.listBox.Location = new System.Drawing.Point(82, 37);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(630, 284);
            this.listBox.TabIndex = 0;
            // 
            // botaoExecutar
            // 
            this.botaoExecutar.Location = new System.Drawing.Point(187, 348);
            this.botaoExecutar.Name = "botaoExecutar";
            this.botaoExecutar.Size = new System.Drawing.Size(153, 66);
            this.botaoExecutar.TabIndex = 1;
            this.botaoExecutar.Text = "Executar";
            this.botaoExecutar.UseVisualStyleBackColor = true;
            this.botaoExecutar.Click += new System.EventHandler(this.botaoExecutar_Click);
            // 
            // botaoLimpar
            // 
            this.botaoLimpar.Location = new System.Drawing.Point(453, 348);
            this.botaoLimpar.Name = "botaoLimpar";
            this.botaoLimpar.Size = new System.Drawing.Size(153, 66);
            this.botaoLimpar.TabIndex = 2;
            this.botaoLimpar.Text = "Limpar";
            this.botaoLimpar.UseVisualStyleBackColor = true;
            this.botaoLimpar.Click += new System.EventHandler(this.botaoLimpar_Click);
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.botaoLimpar);
            this.Controls.Add(this.botaoExecutar);
            this.Controls.Add(this.listBox);
            this.Name = "frmPrincipal";
            this.Text = "Pesquisa Preço";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listBox;
        private System.Windows.Forms.Button botaoExecutar;
        private System.Windows.Forms.Button botaoLimpar;
    }
}

