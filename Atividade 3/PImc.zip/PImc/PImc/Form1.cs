﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;

        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider1.SetError(textBox1, "");
                peso = Convert.ToDouble(textBox1.Text);
            }
            catch 
            {
                errorProvider1.SetError(textBox1, "Peso inválido!");
                textBox1.Focus();
            }
        }

        private void textBox2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(textBox2, "");
                altura = Convert.ToDouble(textBox2.Text);
            }
            catch
            {
                errorProvider2.SetError(textBox2, "Altura inválida!");
                textBox2.Focus();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (peso <= 0)
            {
                errorProvider1.SetError(textBox1, "Peso não pode ser menor que 0!");
                textBox1.Focus();
            }
            else 
            if (altura <= 0)
            {
                errorProvider2.SetError(textBox2, "Altura não pode ser menor ou igual a 0!");
                textBox2.Focus();
            }
            else
            {
                imc = peso / Math.Pow(altura, 2);
                imc = Math.Round(imc, 1);
                textBox4.Text = imc.ToString("G");
                if (imc < 18.5)
                {
                    textBox3.Text = "Magreza";
                    textBox5.Text = "0";
                }
                else
               if (imc < 24.9)
                {
                    textBox3.Text = "Normal";
                    textBox5.Text = "0";
                }
                else
               if (imc < 29.9)
                {
                    textBox3.Text = "Sobrepeso";
                    textBox5.Text = "1";
                }
                else
               if (imc < 39.9)
                {
                    textBox3.Text = "Obesidade";
                    textBox5.Text = "2";
                }
                else
                {
                    textBox3.Text = "Obesidade Grave";
                    textBox5.Text = "3";
                }
            }

                
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Você deseja sair?","Saída", MessageBoxButtons.YesNo,MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
                    
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }
    }
}
