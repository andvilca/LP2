﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int meio = textBox2.Text.Length/2;
            textBox2.Text = textBox2.Text.Substring(0, meio) + textBox1.Text + textBox2.Text.Substring(meio, textBox2.Text.Length - meio);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int meio = textBox1.Text.Length/2;
            textBox2.Text = textBox1.Text.Insert(meio, "**");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.Compare (textBox1.Text, textBox2.Text, true) == 0)
            {
                MessageBox.Show("São Iguais!");
            }
            else
            {
                MessageBox.Show("São Diferentes!");
            }
        }
    }
}
