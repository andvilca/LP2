﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int contaNum = 0;

            while (contador < richTextBox1.Text.Length)
            {
                if (char.IsNumber(richTextBox1.Text[contador]))
                {
                    contaNum++;
                }
                contador++;
            }
            MessageBox.Show($"O texto tem {contaNum} números!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < richTextBox1.Text.Length; i++)
            {
                if (Char.IsWhiteSpace(richTextBox1.Text[i]))
                {
                    MessageBox.Show($"A posição do caracter 1 branco é {i+1}");
                    break;
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int contaLetra = 0;
            foreach (char c in richTextBox1.Text)
            {
                if (Char.IsLetter(c))
                {
                    contaLetra++;
                }
            }
            MessageBox.Show($"O texto tem {contaLetra} letras!");
        }
    }
}
